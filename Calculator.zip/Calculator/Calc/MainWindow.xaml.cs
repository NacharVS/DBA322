﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calc
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        double q, w;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void DeleteAll_Click(object sender, RoutedEventArgs e)
        {
            TextBox1.Clear();
        }

        private void DeleteOne_Click(object sender, RoutedEventArgs e)
        {
            if (TextBox1.Text.Length != 0)
            {
                TextBox1.Text = TextBox1.Text.Remove(TextBox1.Text.Length - 1);
            }
            else
                TextBox1.Text = TextBox1.Text.Insert(TextBox1.Text.Length, "0");
        }

        private void MaksimovPlyushch_Click(object sender, RoutedEventArgs e)
        {
            q = Convert.ToDouble(TextBox1.Text);
            w = Math.Log10(q);
            
            TextBox1.Text = "Ответ: " + w;
        }
    }
}
